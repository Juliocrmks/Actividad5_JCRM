import UIKit

class Persona {
    init() {
        
    }
    func Saludar(nombre: String) -> String {
        return nombre + "Mucho gusto"
    }

    func Caminar(numero: Int) -> String {
        return String(numero)
    }
}

var persona = Persona()
persona.Caminar(numero: 1)


struct Pantalla {
    var ancho: Int
    var alto: Int
    init(ancho: Int, alto: Int) {
        self.ancho = ancho
        self.alto = alto
    }
}
var estructura = Pantalla(ancho:600,alto:600)
estructura.ancho


extension Int {
    var horas: Int {
        return self * 60
    }
}

5.horas

extension String {
    var diaSem: Int {
        if self == "Domingo" {
            return 1
        } else if self == "Lunes" {
            return 2
        } else if self == "Martes" {
            return 3
        } else if self == "Miercoles" {
            return 4
        } else if self == "Jueves" {
            return 5
        } else if self == "Viernes" {
            return 6
        } else if self == "Sabado" {
            return 7
        } else { return 0 }
    }
}

var domingo = "Domingo"

domingo.diaSem

// Optional
var num = [1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8]
var existe: Int?

if let temp = num[23] {
    print("True")

} else {
    print("False")
}
